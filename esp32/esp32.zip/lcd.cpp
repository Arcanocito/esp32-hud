#include "config.h"
#include "lcd.h"

Esp32RgbDisplay lcd;

Esp32RgbDisplay::Esp32RgbDisplay() {
	_bus = new Arduino_ESP32RGBPanel(GFX_NOT_DEFINED, // CS
	                                 GFX_NOT_DEFINED, // SCK
	                                 GFX_NOT_DEFINED, // SDA

	                                 PIN_RGB_DE, PIN_RGB_VSYNC, PIN_RGB_HSYNC, PIN_RGB_PCLK,

	                                 PIN_RGB_R0, PIN_RGB_R1, PIN_RGB_R2, PIN_RGB_R3, PIN_RGB_R4,

	                                 PIN_RGB_G0, PIN_RGB_G1, PIN_RGB_G2, PIN_RGB_G3, PIN_RGB_G4, PIN_RGB_G5,

	                                 PIN_RGB_B0, PIN_RGB_B1, PIN_RGB_B2, PIN_RGB_B3, PIN_RGB_B4);

	_gfx = new Arduino_RPi_DPI_RGBPanel(_bus,

	                                    800, // width
	                                    0,   // hsync polarity
	                                    8,   // hsync front porch
	                                    4,   // hsync pulse width
	                                    8,   // hsync back porch

	                                    480, // height
	                                    0,   // vsync polarity
	                                    8,   // vsync front porch
	                                    4,   // vsync pulse width
	                                    8,   // vsync back porch

	                                    1,        // pixel clock active negative
	                                    16000000, // preferred pixel clock
	                                    true      // auto flush
	);
}

bool Esp32RgbDisplay::init()
{
    ledcSetup(BACKLIGHT_CHANNEL, 1000, 8);
    ledcAttachPin(PIN_BACKLIGHT, BACKLIGHT_CHANNEL);
    ledcWrite(BACKLIGHT_CHANNEL, 0);

    _gfx->begin();
    _gfx->fillScreen(BLACK);

    _initialized = true;
    setBrightness(100);

    return true;
}

void Esp32RgbDisplay::setBrightness(uint8_t percent) {
	percent = constrain(percent, 0, 100);

	const uint8_t duty = map(percent, 0, 100, 0, 255);
	ledcWrite(BACKLIGHT_CHANNEL, duty);
}

void Esp32RgbDisplay::flushWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t* color) {
	if (!_initialized || color == nullptr) {
		return;
	}

	const uint16_t width  = x2 - x1 + 1;
	const uint16_t height = y2 - y1 + 1;

	_gfx->draw16bitRGBBitmap(x1, y1, color, width, height);
}

void Esp32RgbDisplay::invertDisplay(bool invert) {
	/*
	 * RGB panels generally do not support the ST7789-style
	 * hardware inversion command.
	 *
	 * Leave this empty for now. Theme inversion should eventually
	 * be implemented using LVGL colors instead.
	 */
	(void)invert;
}

Arduino_GFX* Esp32RgbDisplay::gfx() {
	return _gfx;
}